const express = require("express");
const cors = require("cors");
const axios = require("axios");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(express.json());
app.use(cors()); // Autorise les appels depuis ton site Lovable

// =============================================
// CONFIG MTN MOMO SANDBOX
// =============================================
const CONFIG = {
  SUBSCRIPTION_KEY: "48927b94feb043819043a4c15a6df927",
  API_USER: "f4b3c2d1-e5a6-4890-bcde-f1234567890a",
  API_KEY: "c2a02a460d3845eaadbe531976f27b2b",
  BASE_URL: "https://sandbox.momodeveloper.mtn.com",
  ENVIRONMENT: "sandbox", // Changer en "mtncongo" en production
  CURRENCY: "EUR", // En sandbox MTN utilise EUR. En production Congo: XAF
};

// =============================================
// ÉTAPE 1 : Obtenir un Access Token
// =============================================
async function getAccessToken() {
  const credentials = Buffer.from(
    `${CONFIG.API_USER}:${CONFIG.API_KEY}`
  ).toString("base64");

  const response = await axios.post(
    `${CONFIG.BASE_URL}/collection/token/`,
    {},
    {
      headers: {
        Authorization: `Basic ${credentials}`,
        "Ocp-Apim-Subscription-Key": CONFIG.SUBSCRIPTION_KEY,
      },
    }
  );

  return response.data.access_token;
}

// =============================================
// ROUTE 1 : Demander un paiement client
// POST /payer
// Body: { montant, numero, reference, description }
// =============================================
app.post("/payer", async (req, res) => {
  const { montant, numero, reference, description } = req.body;

  if (!montant || !numero) {
    return res.status(400).json({
      success: false,
      message: "Montant et numéro MTN requis",
    });
  }

  try {
    const token = await getAccessToken();
    const paymentId = uuidv4(); // ID unique pour ce paiement

    await axios.post(
      `${CONFIG.BASE_URL}/collection/v1_0/requesttopay`,
      {
        amount: String(montant),
        currency: CONFIG.CURRENCY,
        externalId: reference || paymentId,
        payer: {
          partyIdType: "MSISDN",
          partyId: numero, // Numéro MTN du client (ex: 242064759560)
        },
        payerMessage: description || "Paiement commande",
        payeeNote: "Boutique Mario - Merci pour votre achat",
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "X-Reference-Id": paymentId,
          "X-Target-Environment": CONFIG.ENVIRONMENT,
          "Ocp-Apim-Subscription-Key": CONFIG.SUBSCRIPTION_KEY,
          "Content-Type": "application/json",
        },
      }
    );

    res.json({
      success: true,
      paymentId,
      message: "Demande de paiement envoyée. Le client doit confirmer sur son téléphone.",
    });
  } catch (error) {
    console.error("Erreur paiement:", error.response?.data || error.message);
    res.status(500).json({
      success: false,
      message: "Erreur lors de la demande de paiement",
      details: error.response?.data,
    });
  }
});

// =============================================
// ROUTE 2 : Vérifier le statut d'un paiement
// GET /statut/:paymentId
// =============================================
app.get("/statut/:paymentId", async (req, res) => {
  const { paymentId } = req.params;

  try {
    const token = await getAccessToken();

    const response = await axios.get(
      `${CONFIG.BASE_URL}/collection/v1_0/requesttopay/${paymentId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "X-Target-Environment": CONFIG.ENVIRONMENT,
          "Ocp-Apim-Subscription-Key": CONFIG.SUBSCRIPTION_KEY,
        },
      }
    );

    const statut = response.data.status;
    // PENDING = en attente, SUCCESSFUL = payé, FAILED = échoué

    res.json({
      success: true,
      statut,
      paye: statut === "SUCCESSFUL",
      details: response.data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Erreur vérification statut",
    });
  }
});

// =============================================
// ROUTE 3 : Test (pour vérifier que le serveur marche)
// GET /
// =============================================
app.get("/", (req, res) => {
  res.json({
    message: "✅ Backend MTN MoMo - Boutique Mario opérationnel",
    routes: {
      "POST /payer": "Demander un paiement",
      "GET /statut/:id": "Vérifier un paiement",
    },
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Serveur MTN MoMo démarré sur le port ${PORT}`);
});
