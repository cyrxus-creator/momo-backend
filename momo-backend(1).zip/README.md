# Backend MTN MoMo — Boutique Mario

## Déploiement sur Railway (5 minutes)

### Étape 1 : Créer un compte Railway
→ Va sur https://railway.app et inscris-toi avec GitHub

### Étape 2 : Déployer
1. Clique sur "New Project"
2. Choisis "Deploy from GitHub repo"
3. Upload ces fichiers (index.js + package.json)
4. Railway démarre automatiquement le serveur

### Étape 3 : Récupérer ton URL
Railway te donne une URL comme :
https://momo-backend-production.up.railway.app

### Étape 4 : Tester
Ouvre l'URL dans le navigateur → tu verras le message de confirmation

---

## Intégration dans Lovable

Dans ton site Lovable, au moment du checkout, ajoute ce code :

```javascript
const handlePaiementMoMo = async (montant, numeroClient) => {
  const response = await fetch("https://TON-URL.railway.app/payer", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      montant: montant,        // ex: 5000
      numero: numeroClient,    // ex: "242064759560"
      reference: "CMD-001",
      description: "Commande Boutique Mario"
    })
  });
  
  const data = await response.json();
  
  if (data.success) {
    // Vérifier le statut toutes les 5 secondes
    const interval = setInterval(async () => {
      const statut = await fetch(`https://TON-URL.railway.app/statut/${data.paymentId}`);
      const statutData = await statut.json();
      
      if (statutData.paye) {
        clearInterval(interval);
        alert("✅ Paiement confirmé !");
      } else if (statutData.statut === "FAILED") {
        clearInterval(interval);
        alert("❌ Paiement échoué");
      }
    }, 5000);
  }
};
```

---

## Passage en production

Quand tu passes de sandbox à production :
1. Change ENVIRONMENT: "sandbox" → "mtncongo"  
2. Change CURRENCY: "EUR" → "XAF"
3. Remplace les clés par les vraies clés production MTN Congo
